#!/sbin/sh
# Magisk installs this script during module installation

MODPATH=$(dirname $0)

# User messages
ui_print "✅ A friendly community for Xperia users! Let’s keep enjoying Sony Xperia together."

# Ensure script is executable
chmod 0755 "$MODPATH/post-fs-data.sh"
chmod 0755 "$MODPATH/service.sh"

# Remove previous log file (optional)
rm -f /data/local/tmp/KRJP-TETHER.log 2>/dev/null

ui_print "😊 Changes will take effect after reboot."

exit 0