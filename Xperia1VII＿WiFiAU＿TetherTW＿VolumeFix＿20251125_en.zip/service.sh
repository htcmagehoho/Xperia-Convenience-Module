#!/system/bin/sh
# shellcheck disable=SC2169,SC3010

LOGTAG="KRTW-TETHER"
LOGFILE="/data/local/tmp/${LOGTAG}.log"
logi(){ echo "[$(date +'%F %T')] $*" >> "$LOGFILE"; }

# 1) 부팅 완료 대기
until [ "$(getprop sys.boot_completed)" = "1" ]; do sleep 2; done
sleep 5
logi "Boot completed. Applying country codes..."

# 2) STA(클라이언트) Wi-Fi = AU (Settings DB 기록)
if su -lp 2000 -c 'settings put global wifi_country_code AU'; then
  logi "STA country set to AU via settings."
else
  logi "WARN: settings provider not ready; retrying in 5s."
  sleep 5
  su -lp 2000 -c 'settings put global wifi_country_code AU' && logi "Retry OK: STA=AU"
fi

# 3) SoftAP(테더링) = TW 강제
FORCED=0
if cmd wifi help 2>/dev/null | grep -qi "force-country-code"; then
  if cmd wifi force-country-code enabled TW 2>>"$LOGFILE"; then
    FORCED=1; logi "SoftAP country forced to TW (force-country-code)."
  fi
fi

# 대체 명령(빌드별 지원)
if [ "$FORCED" -ne 1 ] && cmd wifi help 2>/dev/null | grep -qi "set-softap-country-code"; then
  if cmd wifi set-softap-country-code TW 2>>"$LOGFILE"; then
    FORCED=1; logi "SoftAP country set to TW (set-softap-country-code)."
  fi
fi

# 실패 시 CA로 롤백(안전)
if [ "$FORCED" -ne 1 ]; then
  cmd wifi force-country-code enabled AU 2>>"$LOGFILE"
  logi "Failed to apply TW. Rolled back SoftAP to AU."
fi

# 4) 상태 출력 (가능 시)
if cmd wifi help 2>/dev/null | grep -qi "get-country-code"; then
  CC=$(cmd wifi get-country-code 2>/dev/null)
  logi "Framework-reported country-code: $CC"
fi

logi "If hotspot was ON already, toggle OFF→ON to apply TW channels."