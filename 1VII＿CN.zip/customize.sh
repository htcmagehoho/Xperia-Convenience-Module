#!/sbin/sh

MODPATH=$(dirname $0)

ui_print "✅ A reliable community for Xperia users! Let's continue to enjoy Sony Xperia together."

exit 0