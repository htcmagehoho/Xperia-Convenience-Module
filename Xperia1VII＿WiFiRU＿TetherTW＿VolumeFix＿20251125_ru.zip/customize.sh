#!/sbin/sh
# Magisk installs this script during module installation

MODPATH=$(dirname $0)

# Пользовательские сообщения
ui_print "✅ Надёжное сообщество пользователей Xperia! Давайте дальше вместе наслаждаться смартфонами Sony Xperia."

# Гарантируем права на исполнение скрипта
chmod 0755 "$MODPATH/post-fs-data.sh"
chmod 0755 "$MODPATH/service.sh"

# Удаление старого лог‑файла (по желанию)
rm -f /data/local/tmp/KRJP-TETHER.log 2>/dev/null

ui_print "😊 Изменения вступят в силу после перезагрузки."

exit 0