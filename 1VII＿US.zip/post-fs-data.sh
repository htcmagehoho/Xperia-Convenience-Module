#!/system/bin/sh
ro.vendor.sony.wlan.6e_cc_list=AT,AU,BE,BG,CA,CH,CN,CY,CZ,DE,DK,EE,ES,FI,FR,GB,GR,HK,HR,HU,IE,IS,IT,JP,KR,LI,LT,LU,LV,MO,MT,MY,NL,NO,PL,PT,RO,RU,SE,SG,SI,SK,TH,TW,US
ro.vendor.sony.wlan.11be_cc_list=AT,AU,BE,BG,CA,CH,CN,CY,CZ,DE,DK,EE,ES,FI,FR,GB,GR,HK,HR,HU,IE,IS,IT,JP,KR,LI,LT,LU,LV,MO,MT,MY,NL,NO,PL,PT,RO,RU,SE,SG,SI,SK,TH,TW,US
settings put global wifi_country_code US