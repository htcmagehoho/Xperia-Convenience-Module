#!/system/bin/sh
# shellcheck disable=SC2169,SC3010

# Xperia Wi-Fi 6E / 11be 지원 국가코드 목록 (벤더 플래그)
resetprop ro.vendor.sony.wlan.6e_cc_list AT,AU,BE,BG,CA,CH,CN,CY,CZ,DE,DK,EE,ES,FI,FR,GB,GR,HK,HR,HU,IE,IS,IT,JP,KR,LI,LT,LU,LV,MO,MT,MY,NL,NO,PL,PT,RO,RU,SE,SG,SI,SK,TH,TW,US

resetprop ro.vendor.sony.wlan.11be_cc_list AT,AU,BE,BG,CA,CH,CN,CY,CZ,DE,DK,EE,ES,FI,FR,GB,GR,HK,HR,HU,IE,IS,IT,JP,KR,LI,LT,LU,LV,MO,MT,MY,NL,NO,PL,PT,RO,RU,SE,SG,SI,SK,TH,TW,US

resetprop wifi_country_code CA